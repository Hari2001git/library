-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2022 at 09:00 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `m_book`
--

CREATE TABLE IF NOT EXISTS `m_book` (
`book_id` bigint(20) NOT NULL,
  `subject_id` bigint(20) NOT NULL,
  `book_title` varchar(100) NOT NULL,
  `book_author` varchar(50) NOT NULL,
  `published_dt` date NOT NULL,
  `published_by` varchar(50) NOT NULL,
  `status` bigint(20) NOT NULL,
  `created_by` varchar(100) NOT NULL,
  `created_dt` datetime(6) NOT NULL,
  `updated_by` varchar(100) NOT NULL,
  `updated_dt` datetime(6) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_book`
--

INSERT INTO `m_book` (`book_id`, `subject_id`, `book_title`, `book_author`, `published_dt`, `published_by`, `status`, `created_by`, `created_dt`, `updated_by`, `updated_dt`) VALUES
(1, 1, 'The Software Development Lifecycles', 'The Software Development Lifecycle', '2022-08-26', 'Charulatha Publication', 1, '1', '2022-08-25 21:40:10.000000', '1', '2022-08-25 22:21:24.000000'),
(3, 2, 'Software Management Lifecycle', 'TomDeMorco', '2022-08-27', 'Technical Publications', 1, '1', '2022-08-25 23:56:31.000000', '', '0000-00-00 00:00:00.000000'),
(4, 3, 'Python For Datascience', 'TomDeMorco', '2022-08-13', 'Charulatha Publications', 1, '1', '2022-08-25 23:57:42.000000', '', '0000-00-00 00:00:00.000000'),
(5, 4, 'Discrete Mathematics', 'Viswabarathi', '2022-08-13', 'Charulatha Publication', 1, '1', '2022-08-25 23:58:26.000000', '', '0000-00-00 00:00:00.000000'),
(6, 5, 'Fundamentals Of Java', 'Marco', '2022-08-13', 'Charulatha Publications', 1, '1', '2022-08-26 00:00:24.000000', '', '0000-00-00 00:00:00.000000'),
(7, 6, 'Fundamentals Of DAA', 'ABCD', '2022-08-28', 'Charulatha Publication', 1, '1', '2022-08-26 00:02:43.000000', '', '0000-00-00 00:00:00.000000'),
(8, 7, 'Fundamentals Of Data Structures', 'DCBA', '2022-08-28', 'Technical Publications', 1, '1', '2022-08-26 00:03:32.000000', '', '0000-00-00 00:00:00.000000'),
(9, 10, 'Fundamentals Of Computer Graphics', 'ABCD', '2022-08-27', 'Technical Publications', 1, '1', '2022-08-26 00:05:54.000000', '', '0000-00-00 00:00:00.000000'),
(10, 9, 'Fundamentals Of Computer Networks', 'DCBA', '2022-08-21', 'Charulatha Publication', 1, '1', '2022-08-26 00:06:35.000000', '', '0000-00-00 00:00:00.000000'),
(11, 9, 'Packet Tracer', 'DCBA', '2022-08-28', 'dfsdfsdf', 1, '1', '2022-08-26 00:07:08.000000', '', '0000-00-00 00:00:00.000000'),
(12, 8, 'Fundamentals Of Software Testing', 'ABCD', '2022-08-26', 'Charulatha Publications', 1, '1', '2022-08-26 00:08:48.000000', '', '0000-00-00 00:00:00.000000'),
(13, 8, 'Black Box', 'ABCD', '2022-08-26', 'Technical Publications', 1, '1', '2022-08-26 00:09:58.000000', '', '0000-00-00 00:00:00.000000'),
(14, 8, 'White Box', 'ABCD', '2022-08-26', 'Technical Publications', 1, '1', '2022-08-26 00:10:38.000000', '', '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `m_district`
--

CREATE TABLE IF NOT EXISTS `m_district` (
`district_id` bigint(20) NOT NULL,
  `country_id` bigint(20) NOT NULL,
  `state_id` bigint(20) NOT NULL,
  `district_name` varchar(200) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `created_dt` datetime NOT NULL,
  `updated_by` bigint(20) NOT NULL,
  `updated_dt` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_district`
--

INSERT INTO `m_district` (`district_id`, `country_id`, `state_id`, `district_name`, `status`, `created_by`, `created_dt`, `updated_by`, `updated_dt`) VALUES
(1, 2, 1, 'x1', 1, 1, '2020-04-22 11:15:28', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `m_subject`
--

CREATE TABLE IF NOT EXISTS `m_subject` (
`subject_id` bigint(20) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `status` tinyint(3) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `created_dt` datetime NOT NULL,
  `updated_by` bigint(20) NOT NULL,
  `updated_dt` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_subject`
--

INSERT INTO `m_subject` (`subject_id`, `subject_name`, `status`, `created_by`, `created_dt`, `updated_by`, `updated_dt`) VALUES
(1, 'Software Engineering', 1, 1, '2022-08-25 20:24:34', 1, '2022-08-25 20:57:16'),
(2, 'Software Project Management', 1, 1, '2022-08-25 20:26:57', 0, '0000-00-00 00:00:00'),
(3, 'Python', 1, 1, '2022-08-25 22:51:12', 0, '0000-00-00 00:00:00'),
(4, 'Mathematics', 1, 1, '2022-08-25 22:51:36', 0, '0000-00-00 00:00:00'),
(5, 'Java', 1, 1, '2022-08-25 22:51:50', 0, '0000-00-00 00:00:00'),
(6, 'Data Analysis And Algorithm', 1, 1, '2022-08-25 22:52:16', 0, '0000-00-00 00:00:00'),
(7, 'Data Structures', 1, 1, '2022-08-25 22:52:29', 0, '0000-00-00 00:00:00'),
(8, 'Software Testing', 1, 1, '2022-08-25 22:52:50', 0, '0000-00-00 00:00:00'),
(9, 'Computer Networks', 1, 1, '2022-08-25 22:53:05', 0, '0000-00-00 00:00:00'),
(10, 'Computer Graphics', 1, 1, '2022-08-25 22:53:46', 0, '0000-00-00 00:00:00'),
(11, 'Web Development', 1, 1, '2022-08-25 22:54:14', 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `m_user`
--

CREATE TABLE IF NOT EXISTS `m_user` (
`user_id` bigint(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_username` varchar(100) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `status` tinyint(2) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  `created_dt` datetime NOT NULL,
  `updated_by` bigint(20) NOT NULL,
  `updated_dt` datetime NOT NULL,
  `company_id` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `m_user`
--

INSERT INTO `m_user` (`user_id`, `user_name`, `user_username`, `user_password`, `status`, `created_by`, `created_dt`, `updated_by`, `updated_dt`, `company_id`) VALUES
(1, '', 'Hari', '12345', 1, 1, '2020-04-10 11:25:30', 0, '0000-00-00 00:00:00', 1),
(2, '', 'Prakash', '12345', 1, 1, '2020-04-29 16:36:28', 0, '0000-00-00 00:00:00', 2),
(3, '', 'Arul', '12345', 1, 1, '2020-04-29 17:08:05', 0, '0000-00-00 00:00:00', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `m_book`
--
ALTER TABLE `m_book`
 ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `m_district`
--
ALTER TABLE `m_district`
 ADD PRIMARY KEY (`district_id`), ADD UNIQUE KEY `country_id` (`country_id`,`state_id`,`district_name`);

--
-- Indexes for table `m_subject`
--
ALTER TABLE `m_subject`
 ADD PRIMARY KEY (`subject_id`), ADD UNIQUE KEY `subject_name` (`subject_name`);

--
-- Indexes for table `m_user`
--
ALTER TABLE `m_user`
 ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `m_book`
--
ALTER TABLE `m_book`
MODIFY `book_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `m_district`
--
ALTER TABLE `m_district`
MODIFY `district_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `m_subject`
--
ALTER TABLE `m_subject`
MODIFY `subject_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `m_user`
--
ALTER TABLE `m_user`
MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
