<!DOCTYPE html>
<html lang="en">
    <head>
       <?php include('includes/header_links.php'); ?>
    </head>
	<?php
		session_start();
		require_once 'functions.class.php';
		$rid =	$_REQUEST['id'];
		$do =	$_REQUEST['do']; 
		$mode =	$_REQUEST['mode']; 
		$column = $do.'_id';
		$table = 'm_'.$do;	
		if(isset($_SESSION['user_id'])){
	?>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
	<?php include('includes/topbar.php'); ?>
    <section>
		<?php include('includes/leftbar.php'); ?>
    </section>
	<?php
		if(isset($do)){
			$string=$_GET['do']."/".$_GET['mode'].".php";
			include($string);
		}
	include('includes/footer_links.php'); 
	?>
	
</body>
<?php } else {
	include('login.php');
}
?>		
</html>
