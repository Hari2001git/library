<?php
	if(isset($_POST['add'])){
		$save=$functionObj->save_patient('4'); 
		if(!$save){
			$error = "error";
		}
	}
?>     
	<section class="content">
        <div class="container-fluid">
            <?php include('includes/navbar.php'); ?>
            <!-- Basic Validation -->
            <div class="row clearfix">
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
						<h2>ADD DATABASE</h2>
                             <?php include('includes/message.php'); ?>
                        <div class="body">
                            <form id="form_validation" method="POST">
								<div class="form-group form-float">
                                    <label class="form-label">DB ID</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="db_id" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Organisation Name</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="organisation_name" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Address</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="address" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
									<label class="form-label">Country</label>
									<select class="form-control show-tick" name="country_name" onchange="load_state(this.value)" required>
										<option value="">--Select Country--</option>
										<?php
											while($crow = mysql_fetch_array($fetch_country)) { 
										?>
										<option value="<?php echo $crow['country_id'];?>"><?php echo $crow['country_name'];?></option>
										<?php } ?>
									</select>
								</div>
								
								<div class="form-group form-float" id="state_name">
								</div>
								
								<div class="form-group form-float" id="city_name">
								</div>
								
								<div class="form-group form-float" id="pin_code">
								</div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Website</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="website" required>
                                    </div>
                                </div>
								
                            </form>
                        </div>
                    </div>
                </div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                        </div>
                        <div class="body">
                            <form id="form_validation" method="POST">
								<div class="form-group form-float">
									<label class="form-label">Industry</label>
									<select class="form-control show-tick" name="industry" required>
										<option value="">--Select Industry--</option>
										<?php
											while($crow = mysql_fetch_array($fetch_country)) { 
										?>
										<option value="<?php echo $crow['country_id'];?>"><?php echo $crow['country_name'];?></option>
										<?php } ?>
									</select>
								</div>
								
								<div class="form-group form-float">
									<label class="form-label">DB Source</label>
									<select class="form-control show-tick" name="db_source" required>
										<option value="">--Select--</option>
										<?php
											while($crow = mysql_fetch_array($fetch_country)) { 
										?>
										<option value="<?php echo $crow['country_id'];?>"><?php echo $crow['country_name'];?></option>
										<?php } ?>
									</select>
								</div>
								
								<div class="form-group form-float">
									<label class="form-label">DB Verified</label>
									<select class="form-control show-tick" name="db verified" required>
										<option value="">--Select--</option>
										<?php
											while($crow = mysql_fetch_array($fetch_country)) { 
										?>
										<option value="<?php echo $crow['country_id'];?>"><?php echo $crow['country_name'];?></option>
										<?php } ?>
									</select>
								</div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Contact Person 1</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="Contact_Person_1 " required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Designation 1</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="designation_1" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Mobile 1</label>
									<div class="form-line">
                                        <input type="number" class="form-control" name="mobile_1" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Telephone 1</label>
									<div class="form-line">
                                        <input type="number" class="form-control" name="telephone_1" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Email 1</label>
									<div class="form-line">
                                        <input type="email" class="form-control" name="email_1" required>
                                    </div>
                                </div>
								
                            </form>
                        </div>
                    </div>
                </div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                        </div>
                        <div class="body">
                            <form id="form_validation" method="POST">
								<div class="form-group form-float">
                                    <label class="form-label">Contact Person 2</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="Contact_Person_2 " required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Designation 2</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="designation_2" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Mobile 2</label>
									<div class="form-line">
                                        <input type="number" class="form-control" name="mobile_2" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Telephone 2</label>
									<div class="form-line">
                                        <input type="number" class="form-control" name="telephone_2" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">Email 2</label>
									<div class="form-line">
                                        <input type="email" class="form-control" name="email_2" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
                                    <label class="form-label">WA No</label>
									<div class="form-line">
                                        <input type="number" class="form-control" name="wa_no" required>
                                    </div>
                                </div>
								
								<div class="form-group form-float">
									<div class="form-line">
										<button class="form-control btn btn-primary waves-effect" type="submit" name="add">SUBMIT</button>
									</div>
                                </div>
                            </form>
                        </div>
                    </div>
					
                </div>
            </div>
            <!-- #END# Basic Validation -->
			
        </div>
    </section>

