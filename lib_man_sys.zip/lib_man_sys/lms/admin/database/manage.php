<?php
	$fetch_usergroup=$functionObj->fetch_usergroup();
	if(isset($_REQUEST['did'])){
		$delete=$functionObj->delete_usergroupByID($_REQUEST['did']); 
	}
?>
	<section class="content">
        <div class="container-fluid">
            <?php include('includes/navbar.php'); ?>
			<!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                MANAGE DATABASE
                            </h2>
							<?php include('includes/message.php'); ?>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>#</th>
											<?php include('includes/action.php'); ?>
											<th style="text-align:center;">Status</th>
											<th>Usergroup</th>
											<th>Created By</th>
											<th>Created Date</th>
											<th>Last Updated By</th>
											<th>Last Updated Date</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>#</th>
											<?php include('includes/action.php'); ?>
											<th style="text-align:center;">Status</th>
											<th>Usergroup</th>
											<th>Created By</th>
											<th>Created Date</th>
											<th>Last Updated By</th>
											<th>Last Updated Date</th>
                                        </tr>
                                    </tfoot>
									<tbody>
                                        <?php
											$cnt = 1;
											if(mysql_num_rows($fetch_usergroup) > 0){
											while($row = mysql_fetch_array($fetch_usergroup)) {
												$id = $row['usergroup_id'];
												$fetch_createdby = $functionObj->fetch_user($row['created_by']);
												$cbrow = mysql_fetch_array($fetch_createdby); 
												$fetch_updatedby = $functionObj->fetch_user($row['updated_by']);
												$ubrow = mysql_fetch_array($fetch_updatedby);
												$checked = "";
												if($row['status'] == '1'){
													$checked = "checked='checked'";
												}
										?>
										<tr>
											<td><?php echo htmlentities($cnt);?></td>
											<?php include('includes/action_row.php'); ?>
											<td><?php echo $row['usergroup_name'];?></td>
											<td><?php echo $cbrow['user_username'];?></td>
											<td><?php echo $row['created_dt'];?></td>
											<td><?php echo $ubrow['user_username'];?></td>
											<td><?php echo $row['updated_dt'];?></td>
										</tr>
										<?php $cnt++; } } else {?>
										<tr>
											<td colspan="6">No Records Found.</td>
										</tr>
										<?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->
        </div>
    </section>
