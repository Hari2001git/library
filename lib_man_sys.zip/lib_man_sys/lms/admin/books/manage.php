<?php
	$fetch_subject	=	$functionObj->fetch_subject('','1'); 
	$fetch_book=$functionObj->fetch_book();
	if(isset($_POST['search'])){
		$fetch_book=$functionObj->search_books(); 
	}
	if(isset($_REQUEST['did'])){
		$delete=$functionObj->delete_bookByID($_REQUEST['did']); 
	}
?>
	<section class="content">
        <div class="container-fluid">
           <?php include('includes/navbar.php'); ?>   
            <!-- Exportable Table -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                MANAGE BOOK
                            </h2>
							<?php include('includes/message.php'); ?>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
						<div class="body">
                            <form id="form_validation" method="POST">
                                <div class="form-group form-float">
									<label class="form-label">Subject</label>
									<select class="form-control show-tick" name="subject_id">
										<option value="">--Select Subject--</option>
										<?php
											while($crow = mysql_fetch_array($fetch_subject)) { 
										?>
										<option value="<?php echo $crow['subject_id'];?>"><?php echo $crow['subject_name'];?></option>
										<?php } ?>
									</select>
								</div>
								<div class="form-group form-float">
                                    <label class="form-label">Book Title</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="book_title">
                                    </div>
                                </div>
								<div class="form-group form-float">
                                    <label class="form-label">Book Author</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="book_author" >
                                    </div>
                                </div>
								<div class="form-group form-float">
                                    <label class="form-label">Published Date</label>
									<div class="form-line">
                                        <input type="date" class="form-control" name="published_dt" >
                                    </div>
                                </div>
								<div class="form-group form-float">
                                    <label class="form-label">Published By</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="published_by" >
                                    </div>
                                </div>
								
								<div class="form-group form-float">
									<button class="btn btn-primary waves-effect" type="submit" name="search">SEARCH</button>
                                </div>                            </form>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover dataTable js-exportable">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Actions</th>
											<th>Subject</th>
											<th>Title</th>
											<th>Author</th>
											<th>Published On</th>
											<th>Published By</th>
											<th>Created By</th>
											<th>Created Date</th>
											<th>Last Updated By</th>
											<th>Last Updated Date</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>#</th>
                                            <th>Actions</th>
											<th>Subject</th>
											<th>Title</th>
											<th>Author</th>
											<th>Published On</th>
											<th>Published By</th>
											<th>Created By</th>
											<th>Created Date</th>
											<th>Last Updated By</th>
											<th>Last Updated Date</th>
                                        </tr>
                                    </tfoot>
									<tbody>
                                        <?php
											$cnt = 1;
											if(mysql_num_rows($fetch_book) > 0){
											while($row = mysql_fetch_array($fetch_book)) {
												$id = $row['book_id'];
												$fetch_createdby = $functionObj->fetch_user($row['created_by']);
												$cbrow = mysql_fetch_array($fetch_createdby); 
												$fetch_updatedby = $functionObj->fetch_user($row['updated_by']);
												$ubrow = mysql_fetch_array($fetch_updatedby);	
										?>
										<tr>
											<td><?php echo htmlentities($cnt);?></td>
											<td>
												<a href="index.php?do=books&mode=edit&id=<?php echo $id; ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
												<a href="#" onclick="confirm_delete('<?php echo $do; ?>','<?php echo $id; ?>')"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
											</td>
											<td><?php echo $row['subject_name'];?></td>
											<td><?php echo $row['book_title'];?></td>
											<td><?php echo $row['book_author'];?></td>
											<td><?php echo $row['published_dt'];?></td>
											<td><?php echo $row['published_by'];?></td>
											<td><?php echo $cbrow['user_username'];?></td>
											<td><?php echo $row['created_dt'];?></td>
											<td><?php echo $ubrow['user_username'];?></td>
											<td><?php echo $row['updated_dt'];?></td>
										</tr>
										<?php $cnt++; } } else {?>
										<tr>
											<td colspan="6">No Records Found.</td>
										</tr>
										<?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Exportable Table -->
        </div>
    </section>
