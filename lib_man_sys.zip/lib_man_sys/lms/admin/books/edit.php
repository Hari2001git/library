<?php
	$fetch_subject = $functionObj->fetch_subject('','1');
	$fetch_bookByID = $functionObj->fetch_book($rid);
	$row = mysql_fetch_array($fetch_bookByID);
	if(isset($_POST['update'])){
		$update=$functionObj->update_book($rid,$_SESSION['user_id']); 
		if(!$update){$error =false; }
	}
?>
	<section class="content">
        <div class="container-fluid">
            <?php include('includes/navbar.php'); ?>
            <!-- Basic Validation -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>EDIT BOOK </h2>
                            <?php include('includes/message.php'); ?>
							<ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <form id="form_validation" method="POST">
                                <div class="form-group form-float">
									<label class="form-label">Subject</label>
									<select class="form-control show-tick" name="subject_id" required>
										<option value="<?php echo $row['subject_id'];?>"><?php echo $row['subject_name'];?></option>
										<option value="">--Select Subject--</option>
										<?php
											while($crow = mysql_fetch_array($fetch_subject)) { 
											if($crow['subject_id'] != $row['subject_name']){
										?>
											<option value="<?php echo $crow['subject_id'];?>"><?php echo $crow['subject_name'];?></option>
										<?php } } ?>
									</select>
								</div>
								<div class="form-group form-float">
                                    <label class="form-label">Book Title</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="book_title" value="<?php echo $row['book_title']; ?>" required>
                                    </div>
                                </div>
								<div class="form-group form-float">
                                    <label class="form-label">Book Author</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="book_author" value="<?php echo $row['book_author']; ?>" required>
                                    </div>
                                </div>
								<div class="form-group form-float">
                                    <label class="form-label">Published On</label>
									<div class="form-line">
                                        <input type="date" class="form-control" name="published_dt" value="<?php echo $row['published_dt']; ?>" required>
                                    </div>
                                </div>
								<div class="form-group form-float">
                                    <label class="form-label">Published By</label>
									<div class="form-line">
                                        <input type="text" class="form-control" name="published_by" value="<?php echo $row['published_by']; ?>" required>
                                    </div>
                                </div>
								<div class="form-group form-float">
									<button class="btn btn-primary waves-effect" type="submit" name="update">SUBMIT</button>
                                </div>                            
							</form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Validation -->
        </div>
    </section>

