<?php
require_once 'functions.class.php';
$country = $_REQUEST['country_id'];
$state = $_REQUEST['state_id'];
$ival = $_REQUEST['ival'];
$icol = $_REQUEST['icol'];
$itable = $_REQUEST['itable'];

if($country != '') {
	$fetch_state	= $functionObj->fetch_state('',$country,'1'); 
	$result = "<label class='form-label'>State</label>
				<select class='form-control show-tick' name='state_name' onchange='load_city(this.value)' required>
				<option value=''>--Select State--</option>";
	while($srow = mysql_fetch_array($fetch_state)) { 
		$state_id = $srow['state_id'];
		$state_name = $srow['state_name'];
		$result .= "<option value='$state_id'>$state_name</option>";
	} 
	$result .= "</select>";
	echo $result;
}

if($state != '') {
	$fetch_city	= $functionObj->fetch_city('',$state,'1'); 
	$result = "<label class='form-label'>City</label>
				<select class='form-control show-tick' name='city_name' onchange='load_hospital(this.value)'  required>
				<option value=''>--Select City--</option>";
	while($crow = mysql_fetch_array($fetch_city)) { 
		$city_id = $crow['city_id'];
		$city_name = $crow['city_name'];
		$result .= "<option value='$city_id'>$city_name</option>";
	} 
	$result .= "</select>";
	echo $result;
}

if(isset($ival)) {
	$update_status	= $functionObj->update_status($icol,$rid,$ival,$itable,$_SESSION['user_id']); 
	echo $update_status;
}

?>