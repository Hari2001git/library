﻿<?php 
	session_start();
	$error  = "";
	if(isset($_POST['signin'])){
		$result=$functionObj->check_login();
		$row = mysql_fetch_array($result);
		if(mysql_num_rows($result) > 0){
			$_SESSION['user_id']=$row['user_id'];
			$_SESSION['user_name']=$row['user_name'];
			$_SESSION['user_password']=$pwd = $row["user_password"];

			echo "<script>window.location.href='index.php?do=books&mode=manage';</script>";
					
		}else{
			$error  = "Incorrect username or password!!";
		}
    }
?>
<style>
		.rcorners3 {
		 background: #fff; 
		 padding: 1px;
		 text-align:center;
		}
</style>
<body class="login-page">
    <div class="login-box">
        <div class="card">
            <div class="body">
                <form id="sign_in" method="POST">
                    <div class="msg"><b>Welcome to Books World </b></div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">person</i>
                        </span>
                        <div class="form-line">
                            <input type="text" class="form-control" name="user_username" placeholder="Username" required autofocus>
                        </div>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="material-icons">lock</i>
                        </span>
                        <div class="form-line">
                            <input type="password" class="form-control" name="user_password" placeholder="Password" required>
                        </div>
						<label class="error"><?php echo $error; ?></label>                    
                    </div>
                    <div class="row">
                        <div class="col-xs-8 p-t-5">
                        </div>
                        <div class="col-xs-4">
                            <button class="btn btn-block bg-onista-green waves-effect" name="signin" type="submit">SIGN IN</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include('includes/footer_links.php'); ?>
</body>

</html>