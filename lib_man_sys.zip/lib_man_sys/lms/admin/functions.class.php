<?php 
error_reporting(0);
class functions {
	
	/* 	DB CONNECTION */

    protected $conn;

    public function __construct() {
        $this->DbConnect();
    }

    protected function DbConnect() {
		
		/* 	LOCAL DB CONNECTION */
		$this->conn = @mysql_connect('localhost', 'root', '') OR die("Unable to connect to the database");
        
		mysql_select_db('lms', $this->conn) OR die("can not select the database onistacr_crm"); 
        return TRUE;
    }
    //used
	
	/* Subject */
	
	public function save_subject($user){
		$name = $_POST['subject_name'];
		$qry = "INSERT INTO m_subject (
					`subject_name`,
					`status`,
					`created_by`, 
					`created_dt`) 
				VALUES(
					'$name',
					'1',
					'$user',
					now())";
		$result= mysql_query($qry);
		return $result;
	}
	//used
	
	public function fetch_subject($id,$status)
	{
		$cond ="";
		
		if(isset($status)){
			$status ="status = '1'";
		}else{
			$status ="status >= '1'";
		}
		
		if($id != ''){
			$cond="AND subject_id = $id ";
		}
		
		$qry="SELECT * FROM m_subject WHERE $status $cond";
		$result = mysql_query($qry);
		return $result;
	}
	//used
	
	public function update_subject($id,$user) {
		$subject_name = $_POST["subject_name"];
		$qry = "UPDATE m_subject SET subject_name = '$subject_name', updated_by = '$user', updated_dt = now() WHERE subject_id='$id'";        
		$result = mysql_query($qry);
		return $result;
    }
	//used
	
	public function delete_subjectByID($id){
		$qry="DELETE FROM m_subject WHERE subject_id='$id'";
		$result = mysql_query($qry);
		return $result;
	}
	//used
	
	/* Books */
	
	public function save_books($user){
		$subject_id = $_POST['subject_id'];
		$book_title = $_POST['book_title'];
		$book_author = $_POST['book_author'];
		$published_dt = $_POST['published_dt'];
		$published_by = $_POST['published_by'];
		$qry = "INSERT INTO m_book (
					`subject_id`,
					`book_title`,
					`book_author`,
					`published_dt`,
					`published_by`,
					`status`,
					`created_by`, 
					`created_dt`) 
				VALUES(
					'$subject_id',
					'$book_title',
					'$book_author',
					'$published_dt',
					'$published_by',
					'1',
					'$user',
					now())";
		$result= mysql_query($qry);
		return $result;
	}
	//used
	
	public function fetch_book($id,$status)
	{
		$cond ="";
		
		if(isset($status)){
			$status ="b.status = '1'";
		}else{
			$status ="b.status >= '1'";
		}
		
		if($id != ''){
			$cond="AND b.book_id = $id ";
		}
		
		$qry="SELECT b.*,s.subject_name FROM m_book b 
			  INNER JOIN m_subject s ON b.subject_id = s.subject_id
			  WHERE $status $cond";
		$result = mysql_query($qry);
		return $result;
	}
	//used
	
	public function search_books()
	{
		$subject_id = $_POST['subject_id'];
		$book_title = $_POST['book_title'];
		$book_author = $_POST['book_author'];
		$published_dt = $_POST['published_dt'];
		$published_by = $_POST['published_by'];

		$cond ="";
		
		$status ="b.status = '1'";
		
		if($subject_id != ''){
			$cond .= "AND b.subject_id = $subject_id ";
		}
		
		if($book_title != ''){
			$cond .= "AND b.book_title = '$book_title' ";
		}
		
		if($book_author != ''){
			$cond .= "AND b.book_author = '$book_author' ";
		}
		
		if($published_dt != ''){
			$cond .= "AND b.published_dt = '$published_dt' ";
		}
		
		if($published_by != ''){
			$cond .= "AND b.published_by = '$published_by' ";
		}
		
		$qry="SELECT b.*,s.subject_name FROM m_book b 
			  INNER JOIN m_subject s ON b.subject_id = s.subject_id
			  WHERE $status $cond";
		$result = mysql_query($qry);
		return $result;
	}
	//used

	public function update_book($id,$user) {
		$subject_id = $_POST['subject_id'];
		$book_title = $_POST['book_title'];
		$book_author = $_POST['book_author'];
		$published_dt = $_POST['published_dt'];
		$published_by = $_POST['published_by'];
		$qry = "UPDATE m_book SET subject_id = '$subject_id',book_title = '$book_title',book_author = '$book_author',published_dt = '$published_dt',published_by = '$published_by',updated_by = '$user', updated_dt = now() WHERE book_id='$id'";        
		$result = mysql_query($qry);
		return $result;
    }
	//used
	
	public function delete_bookByID($id){
		$qry="DELETE FROM m_book WHERE book_id='$id'";
		$result = mysql_query($qry);
		return $result;
	}
	//used
	
	/* DASHBOARD */
	
	public function dashboard_count() {
		$qry = "SELECT (SELECT count(*) FROM m_state s WHERE s.status='1') AS state,
				(SELECT count(*) FROM m_city c WHERE c.status='1') AS city,
				(SELECT count(*) FROM m_hospital h WHERE h.status='1') AS hospital,
				(SELECT count(*) FROM m_speciality sp WHERE sp.status='1') AS speciality,
				(SELECT count(*) FROM m_doctor d WHERE d.status='1') AS doctor";
		$result = mysql_query($qry);
		return $result;
    }
	//used
	
	public function check_login()
	{
		$cond = "";
		$user_username = $_POST['user_username'];
		$user_password = $_POST['user_password'];
		$qry= "SELECT u.* FROM m_user u 
			   WHERE u.user_username='$user_username' AND u.user_password='$user_password'";
		$result= mysql_query($qry);
		return $result;
	}
	//used
		
	public function fetch_user($id,$usergroup_name,$status)
	{
		$cond ="";
		
		if(isset($status)){
			$status ="u.status = '1'";
		}else{
			$status ="u.status >= '1'";
		}
		
		if($id != ''){
			$cond="AND u.user_id = $id ";
		}
		
		$qry= "SELECT u.* FROM m_user u 
				WHERE $status $cond";
		$result= mysql_query($qry);
		return $result;
	}
	//used
	
}
$functionObj = new functions();
?>