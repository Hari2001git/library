<div class="block-header">
	<a href="index.php?do=dashboard&amp;mode=dashboard" class="toggled waves-effect" >
        <i class="material-icons" >home</i>
    </a>
	<a href="index.php?do=<?php echo $do; ?>&amp;mode=manage" class="toggled waves-effect">
       <i class="material-icons">view_list</i>
    </a>
	<a href="index.php?do=<?php echo $do; ?>&amp;mode=add" class="toggled waves-effect">
       <i class="material-icons">note_add</i>
    </a>
</div>