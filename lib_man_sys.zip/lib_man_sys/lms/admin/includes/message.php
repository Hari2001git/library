<?php if($save){ ?>
    <div class="card">
        <div class="header bg-green">
			<h2>
               Success Message:
            </h2>
        </div>
        <div class="body">
             Well done! Added Successfully.               
        </div>
		<script type="text/javascript">
			setTimeout(function() {
				window.location.href = "index.php?do=<?php echo $do; ?>&mode=<?php echo ($mode == 'add_access') ? 'edit&id='.$rid : (($do == 'usergroup') ? 'add_access&id='.$rid : 'add'); ?>";
			}, 3000);
		</script>
	</div>
<?php } else if($error){?>
	<div class="card">
        <div class="header bg-red">
			<h2>
               Error Message:
            </h2>
        </div>
        <div class="body">
             Oh snap! Error while saving.               
        </div>
		<script type="text/javascript">
			setTimeout(function() {
				window.location.href = "";
			}, 3000);
		</script>
	</div>
<?php } else if($update){?>
    <div class="card">
        <div class="header bg-green">
			<h2>
               Success Message:
            </h2>
        </div>
        <div class="body">
             Well done! Updated Successfully.               
        </div>
		<script type="text/javascript">
			setTimeout(function() {
			window.location.href = "index.php?do=<?php echo $do; ?>&mode=manage";
		}, 3000);
		</script>
	</div>
<?php } else if($delete){?>
    <div class="card">
        <div class="header bg-green">
			<h2>
               Success Message:
            </h2>
        </div>
        <div class="body">
             Well done! Deleted Successfully.               
        </div>
		<script type="text/javascript">
			setTimeout(function() {
			window.location.href = "index.php?do=<?php echo $do; ?>&mode=manage";
		}, 3000);
		</script>
	</div>
<?php } ?>
