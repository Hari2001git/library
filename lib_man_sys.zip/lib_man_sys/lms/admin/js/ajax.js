$(function(){
    $(":checkbox").click(function(){
		$(this).nextAll(':hidden').first().val( $(this).is(':checked') ? '1' : '0' );
    });
	
	$("#select_all").click(function(){
        $(":checkbox").prop('checked', $(this).prop('checked'));
		$(":checkbox").nextAll(':hidden').val( $(":checkbox").is(':checked') ? '1' : '0' );
	});
});

function load_dealer(ival) {
	if(ival == "5"){
		document.getElementById("dealer_name").style.display="block";
	}    
}

function load_state(ival) {
	document.getElementById("state_name").innerHTML = "";
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
			document.getElementById("state_name").innerHTML = this.responseText;
			load_city();
	   }
    };
    xmlhttp.open("GET", "ajax.php?country_id="+ival, true);
    xmlhttp.send();
}

function load_city(ival) {
	document.getElementById("city_name").innerHTML = "";
	var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
			document.getElementById("city_name").innerHTML = this.responseText;
	   }
    };
    xmlhttp.open("GET", "ajax.php?state_id="+ival, true);
    xmlhttp.send();
}

function confirm_password(imode,ival){
	var inew = document.getElementById("NewPassword").value;
	if (imode == 'co' && inew != ival) {
	  document.getElementById("NewPassword").value = "";
	  document.getElementById("NewPasswordConfirm").value = "";
	  document.getElementById("error_confirm").innerHTML = "<label id='confirm-pwd-error' class='error'>Password and Confirm Password does not match.</label>";
	} 
	var iold = document.getElementById("hdn_OldPassword").value;
	document.getElementById("error_old").innerHTML = "";
	if (imode == 'ch' && iold != ival) {
	  document.getElementById("OldPassword").value = "";
	  document.getElementById("error_old").innerHTML = "<label id='old-pwd-error' class='error'>This is not your old password.</label>";
	} 
}

function update_status(icol,id,itable,ival){
	var ch_ival = '1';
	if(ival == '1'){
		ch_ival = '2' ;
	}
	if (confirm("Are you sure to update status?")) {
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
		   if (this.readyState == 4 && this.status == 200) {
				document.getElementById("status").checked = false;
				if(ch_ival == '1'){
					document.getElementById("status").checked = true;
				}
				window.location.href = "";
		   }
		};
		xmlhttp.open("GET", "ajax.php?ival="+ch_ival+"&icol="+icol+"&id="+id+"&itable="+itable, true);
		xmlhttp.send();
	} else {
	  window.location.href = "";
	}
}

function confirm_delete(ido,ival){
	if (confirm("Are you sure to delete?")) {
	  window.location.href="index.php?do="+ido+"&mode=manage&did="+ival;
	} else {
	  return false;
	}
}

function checkAll(source) {
     var checkboxes = document.getElementsByName(source.name);
     if (source.checked) {
         for (var i = 0; i < checkboxes.length; i++) {
             if (checkboxes[i].type == 'checkbox') {
                 checkboxes[i].checked = true;
				 $(checkboxes[i]).nextAll(':hidden').first().val( $(checkboxes[i]).is(':checked') ? '1' : '0' );
             }
         }
     } else {
         for (var i = 0; i < checkboxes.length; i++) {
             console.log(i)
             if (checkboxes[i].type == 'checkbox') {
                 checkboxes[i].checked = false;
				 $(checkboxes[i]).nextAll(':hidden').first().val( $(checkboxes[i]).is(':checked') ? '1' : '0' );
			 }
         }
     }
}

$(document).ready(function(){
	var select_all = [];
	var menu = ['usergroup','user','country','state','city','industry','dbsource','dbverified','leadowner','leadassignedto','leadsource','leadstage','accountsource','category','product','database','leads','accounts'];
	menu.forEach(fillCheckboxes);
	function fillCheckboxes(source) {
		var name = source+'_all';
		var values = [];
		var checkboxes = document.getElementsByName(name);
		for (var i = 0; i < checkboxes.length; i++) {
			if (checkboxes[i].checked && checkboxes[i].id != name) {
				values.push(checkboxes[i].value);
				select_all.push(checkboxes[i].value);
				$(checkboxes[i]).nextAll(':hidden').first().val( $(checkboxes[i]).is(':checked') ? '1' : '0' );
			}
		}
		if (values.length == 4) {
			document.getElementById(name).checked = true;
		}
		
		if (select_all.length == 64) {
			document.getElementById("select_all").checked = true;
		}
	}
});




